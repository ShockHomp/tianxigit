<?php
/**
 * 上传附件和上传视频
 * User: Jinqn
 * Date: 14-04-09
 * Time: 上午10:17
 */
include "Uploaders.class.php";

require_once '../../../../www/init.php';
require_once '../../../../www/init_smarty.php';

// session_start();

require_once FRAMEWORK_PATH . '/library/common.lib.php';
require_once FRAMEWORK_PATH . '/library/mysql.class.php';
require_once FRAMEWORK_PATH . '/library/session.class.php';
require_once FRAMEWORK_PATH . '/library/cos/vendor/autoload.php';

/* 上传配置 */
$base64 = "upload";
switch (htmlspecialchars($_GET['action'])) {
    case 'uploadimage':

//        var_dump($_FILES);
// START 2021/1/11 修改 百富文本编辑器 上传云服务器(图片)
        $goods_img		=   "";
//        $imgArray=array();
//        foreach($_FILES as $k=>$v){

            require_once FRAMEWORK_PATH . '/library/upload.class.php';

            //上传配置
            $configs = array(
                "savePath" => $GLOBALS['DATA_PATH']."/upload/" ,
                "maxSize" => 2048 , //单位KB
                "allowFiles" => array( ".gif" , ".png" , ".jpg" , ".jpeg" , ".bmp" ,".flv" , ".wmv" , ".rmvb" , ".mp4" )
            );
            //生成上传实例对象并完成上传
            $ups = new Uploader( 'upfile' , $configs );
            $info = $ups->getFileInfo();

//             var_dump($info);
            $goods_img   = str_replace($GLOBALS['DATA_PATH'], '', $info["url"]);

            $goods_img_local = $GLOBALS['DATA_PATH'].$goods_img;

            $goods_img_s = cos_upload($goods_img_local);

//			echo json_encode(array('error' => 0, 'url' =>$goods_img_s));
            // 1214 修改
//            array_push($imgArray,$goods_img_s);

//        }
        return '{"state":"'.$info['state'].'","url":"'.$goods_img_s.'","original":"'.$info['originalName'].'","type":"'.$info['type'].'","size":'.$info['size'].'}';

// END
        $config = array(
            "pathFormat" => $CONFIG['imagePathFormat'],
            "maxSize" => $CONFIG['imageMaxSize'],
            "allowFiles" => $CONFIG['imageAllowFiles']
        );
        $fieldName = $CONFIG['imageFieldName'];
        break;
    case 'uploadscrawl':
        $config = array(
            "pathFormat" => $CONFIG['scrawlPathFormat'],
            "maxSize" => $CONFIG['scrawlMaxSize'],
            "allowFiles" => $CONFIG['scrawlAllowFiles'],
            "oriName" => "scrawl.png"
        );
        $fieldName = $CONFIG['scrawlFieldName'];
        $base64 = "base64";
        break;
    case 'uploadvideo':
        $config = array(
            "pathFormat" => $CONFIG['videoPathFormat'],
            "maxSize" => $CONFIG['videoMaxSize'],
            "allowFiles" => $CONFIG['videoAllowFiles']
        );
        $fieldName = $CONFIG['videoFieldName'];
        break;
    case 'uploadfile':
    default:
        $config = array(
            "pathFormat" => $CONFIG['filePathFormat'],
            "maxSize" => $CONFIG['fileMaxSize'],
            "allowFiles" => $CONFIG['fileAllowFiles']
        );
        $fieldName = $CONFIG['fileFieldName'];
        break;
}

/* 生成上传实例对象并完成上传 */
$up = new Uploaders($fieldName, $config, $base64);

/**
 * 得到上传文件所对应的各个参数,数组结构
 * array(
 *     "state" => "",          //上传状态，上传成功时必须返回"SUCCESS"
 *     "url" => "",            //返回的地址
 *     "title" => "",          //新文件名
 *     "original" => "",       //原始文件名
 *     "type" => ""            //文件类型
 *     "size" => "",           //文件大小
 * )
 */

/* 返回数据 */
//return '{"state":"SUCCESS","url":"\/ueditor\/php\/upload\/image\/20210111\/1610351118614822.jpg","title":"1610351118614822.jpg","original":"4.jpg","type":".jpg","size":19186}';
$aa=$up->getFileInfo();
//$aa['url']='/ueditor/php/upload/image/20210111/1610351118614822.jpg';

//if(!empty($goods_img_s)){
//    $aa['url']=$goods_img_s;
//}
return json_encode($aa);
